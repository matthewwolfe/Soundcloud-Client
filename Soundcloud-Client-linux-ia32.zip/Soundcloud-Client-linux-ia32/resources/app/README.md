# Soundcloud Client
An open source soundcloud desktop app built using React and Electron

[Website](http://matthewwolfe.github.io/Soundcloud-Client/)


##To Build
```
// clone
git clone https://github.com/matthewwolfe/Soundcloud-Client.git

// set up the build tools
npm install
npm run gulp
npm run sass
npm run webpack

// start the application
npm run start

// package the application
npm run package
```
